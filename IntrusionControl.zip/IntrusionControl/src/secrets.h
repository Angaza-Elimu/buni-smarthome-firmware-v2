#ifndef SECRETS_H
#define SECRETS_H

#define SSID "your_wifi_ssid"
#define PASSWORD "your_wifi_password"
#define API_KEY "your_smoke_sensor_api_key"

#endif
