#ifndef CERTIFICATES_H
#define CERTIFICATES_H

// These are declared but NOT defined here.
// They are implemented in lib/certificates.a
extern const char* root_cacert;
extern const char* server_url;

#endif
