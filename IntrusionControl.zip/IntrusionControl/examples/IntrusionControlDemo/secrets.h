#ifndef SECRETS_H
#define SECRETS_H

// WiFi details and API Key definition
#define SSID "your_SSID"
#define PASSWORD "your_PASSWORD"
#define API_KEY "your_API_KEY"

#endif
