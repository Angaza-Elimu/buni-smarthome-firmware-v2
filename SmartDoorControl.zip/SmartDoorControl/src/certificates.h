#ifndef CERTIFICATES_H
#define CERTIFICATES_H

// These values are defined in libcertificates.a (not visible in source)
extern const char* root_cacert;
extern const char* server_url;

#endif
