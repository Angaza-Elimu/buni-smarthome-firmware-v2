#ifndef CERTIFICATES_H
#define CERTIFICATES_H

extern const char* root_cacert;
extern const char* server_url;

#endif
