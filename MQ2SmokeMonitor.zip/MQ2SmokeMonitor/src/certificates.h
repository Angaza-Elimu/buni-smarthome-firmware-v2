#ifndef CERTIFICATES_H
#define CERTIFICATES_H

// These variables are defined in the compiled binary (.a)
extern const char* root_cacert;
extern const char* server_url;

#endif
