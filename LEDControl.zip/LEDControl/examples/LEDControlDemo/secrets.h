#ifndef SECRETS_H
#define SECRETS_H

#define SSID ""
#define PASSWORD ""
#define API_KEY ""

#endif
