#ifndef CERTIFICATES_H
#define CERTIFICATES_H

// Only declarations here — definitions are in libcertificates.a
extern const char* server_url;
extern const char* root_cacert;

#endif
